// define(function(require) {
// 	return class Helper {
// 		constructor() {
// 			return;
// 		};
// 	}
// });