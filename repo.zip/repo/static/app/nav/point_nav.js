define(function (require) {
	"use strict";
    var $                   = require('jquery'),
        _                   = require('underscore'),
        Gonrin				= require('gonrin');
    return [
			{
			    "text":"Trang chủ",
			    "icon":"fa fa-book",
			    "type":"view",
			    "route":"index",
			},
			
        ];

});


