define(function (require) {
	"use strict";
    var $                   = require('jquery'),
        _                   = require('underscore'),
        Gonrin				= require('gonrin');
    return [
			{
			    "text":"Trang chủ",
			    "icon":"fa fa-book",
			    "type":"view",
			    "route":"index",
			},
			{
			    "text":"Thông tin thương hiệu",
			    "icon":"fa fa-book",
			    "type":"view",
			    "route":"merchant/model?merchant_id={{merchant_id}}",
			    "$ref": "app/merchant/view/ModelView"
			},
            {
			    "text":"Danh sách POS",
			    "icon":"fa fa-book",
			    "type":"view",
			    "collectionName":"posinfo",
			    "route":"pos/collection?merchant_id={{merchant_id}}",
			    "$ref": "app/pos/view/CollectionView"
			},
            {
			    "text":"Danh sách nhóm POS",
			    "icon":"fa fa-book",
			    "type":"view",
			    "collectionName":"pos_categories",
			    "route":"pos_categories/collection?merchant_id={{merchant_id}}",
			    "$ref": "app/pos_category/view/CollectionView"
			},
            {
			    "text":"Danh sách Món",
			    "icon":"fa fa-book",
			    "type":"view",
			    "collectionName":"items",
			    "route":"items/collection?merchant_id={{merchant_id}}",
			    "$ref": "app/items/view/CollectionView"
			},
            {
			    "text":"Danh sách nhóm Món",
			    "icon":"fa fa-book",
			    "type":"view",
			    "collectionName":"item_categories",
			    "route":"item_categories/collection?merchant_id={{merchant_id}}",
			    "$ref": "app/item_category/view/CollectionView"
			},
            {
			    "text":"Danh sách loại Món",
			    "icon":"fa fa-book",
			    "type":"view",
			    "collectionName":"item_type",
			    "route":"item_type/collection?merchant_id={{merchant_id}}",
			    "$ref": "app/item_type/view/CollectionView"
			},
            {
			    "text":"Danh sách bài viết",
			    "icon":"fa fa-book",
			    "type":"view",
			    "collectionName":"article",
			    "route":"article/collection?merchant_id={{merchant_id}}",
			    "$ref": "app/article/view/CollectionView"
			},
            {
			    "text":"Quản lý voucher",
			    "icon":"fa fa-book",
			    "type":"view",
			    "collectionName":"voucher",
			    "route":"voucher/collection?merchant_id={{merchant_id}}",
			    "$ref": "app/voucher/view/CollectionView"
			},
        ];

});


