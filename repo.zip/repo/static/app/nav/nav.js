define(function (require) {
	"use strict";
	var $ = require('jquery'),
		_ = require('underscore'),
		Gonrin = require('gonrin');


	return [
		{
			"text": "Trang Chủ",
			"icon": "fa fa-book",
			"type": "view",
			"route": "index",
		},
		// {
		// 	"text": "Quản Lý Tai Khoản",
		// 	"icon": "fa fa-users",
		// 	"type": "category",
		// 	"visible": true,
		// 	"entries": [
		// 		{
		// 			"text": "Người dùng",
		// 			"type": "view",
		// 			"icon": "fa fa-user",
		// 			"collectionName": "user",
		// 			"route": "user/collection",
		// 			"$ref": "app/user/user/view/CollectionView",
		// 			"visible": true
		// 		},
		// 		{
		// 			"type": "view",
		// 			"collectionName": "user",
		// 			"route": "user/model(/:id)",
		// 			"$ref": "app/user/user/view/Tenancy/ModelView",
		// 			"visible": false
		// 		},
		// 		{
		// 			"text": "Vai trò",
		// 			"type": "view",
		// 			"icon": "fa fa-user",
		// 			"collectionName": "role",
		// 			"route": "role/collection",
		// 			"$ref": "app/role/role/view/CollectionView",

		// 		},
		// 		{
		// 			"type": "view",
		// 			"collectionName": "role",
		// 			"route": "role/model(/:id)",
		// 			"$ref": "app/role/role/view/Tenancy/ModelView",
		// 			"visible": false
		// 		}

		// 	]
		// },
		
		{
			"text": "SIEM",
			"icon": "fa fa-cogs",
			"type": "category",
			"visible": true,
			"entries": [
				{
					"text": "Phân Tích Log - Regex",
					"type": "view",
					
					"collectionName": "siem",
					"route": "siem/collection",
					"$ref": "app/siem/view/siem",
					"visible": true
				},
				{
					"type": "view",
					"collectionName": "siem",
					"route": "siem/model(/:id)",
					"$ref": "app/siem/view/ModelView",
					"visible": false
				},
				

			]
		},
		
		
	];

});


