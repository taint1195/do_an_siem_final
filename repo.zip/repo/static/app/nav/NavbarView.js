define(function (require) {
    "use strict";
    var $                   = require('jquery'),
        _                   = require('underscore'),
        Gonrin				= require('gonrin');

	var template = '<section class="sidebar">'+
	'<form action="#" method="get" class="sidebar-form">'+
        '<div class="input-group">'+
		    '<input type="text" name="q" class="form-control" placeholder="Search...">'+
		    '<span class="input-group-btn">'+
		          '<button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>'+
		          '</button>'+
		        '</span>'+
		  '</div>'+
		  
		'</form>'+
		'<ul class="sidebar-menu tree" data-widget="tree">'+
//        	'<li class="header">MAIN MENU</li>'+
        '</ul>'+
		'</section>';
	
	
	//var navdata = require('app/Nav/nav');
	var navdata = require('app/nav/nav');
	var point_nav = require('app/nav/point_nav');
	var merchant_nav = require('app/nav/merchant_nav');
	
	//var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || $( window ).width() <= 767;
    
	
	return Gonrin.View.extend({
    	checkUser: function(){
    	    var isUser = gonrinApp().currentUser != null ? gonrinApp().currentUser.hasRole('User'): false;
    	    return isUser;
    	},
    	userHasRole: function(role){
    	    var is = gonrinApp().currentUser != null ? gonrinApp().currentUser.hasRole(role): false;
    	    return is;
    	},
    	requireRole: function(role){
    		var user = gonrinApp().currentUser;
    		if (!!user && user.role === role){
    			return true;
    		}
    		return false;
    	},
    	requirePointRole: function(point_name, role){
    		var user = gonrinApp().currentUser;
    		if (!!user){
    			for (var i = 0; i < user.points.length; i++){
    				var point = user.points[i];
    				if ((point_name === point.point_name) && (role === point.role)){
    					return true;
    				}
    			}
    		}
    		return false;
    	},
    	loadEntries: function($el, entries, is_root){
			var self = this;
			var check_first = false;
			if(entries && (entries.length > 0)){
				_.each(entries, function(entry, index){
					var entry_type = _.result(entry, 'type');
					//var entry_collectionName = _.result(entry, 'collectionName');
					var entry_ref = _.result(entry, '$ref');
					var entry_text = _.result(entry, 'text');
					var entry_icon = _.result(entry, 'icon');
					var entry_entries = _.result(entry, 'entries');
					var entry_viewData = _.result(entry, 'viewData');
					var _html = '';
					if(entry_type === "category"  && entry_text !== undefined){
						_html = _html + '<a href="javascript:void(0);">';
						if(entry_icon){
							_html = _html + '<i class="' + entry_icon + '" aria-hidden="true"></i>';
						}
						_html = _html + '<span >'+ entry_text +'</span>';
						_html = _html + '<span class="pull-right-container">'+
			              '<i class="fa fa-angle-left pull-right"></i>'+
			            '</span>';		
						_html = _html + '</a>';
					}
					
					if(entry_type === "view" && entry_text !== undefined){
						_html = _html + '<a class="grview" href="javascript:;">';
						if(entry_icon){
							_html = _html + '<i class="' + entry_icon + '"></i>'; //change icon
						}
						_html = _html +  entry_text;
						_html = _html + '</a>';
					}
					var $entry = $('<li>').html(_html);
					if(entry_type === "category"){
						$entry.addClass("treeview")
					}
					
					if($el){
						$el.append($entry);
					}
					
					if (entry_entries) {
						var _nav_list = $('<ul>').addClass("treeview-menu").appendTo($entry);
						self.loadEntries(_nav_list, entry_entries, false);
					}
					//self.loadView(entry);
					if(self.isEntryVisible(entry)){
						self.handleEntryClick($entry, entry);
					}else{
						$entry.hide();
					}
					
//					if(self.isEntryVisible(entry)){
//						self.handleEntryClick($entry, entry);
//						if(check_first === false){
//							check_first = true;
//							$entry.addClass("current");
//						}
//					} else {
//						self.handleEntryClick($entry, entry);
//						$entry.hide();
//					}
//					if((index === 0)&&(is_root === true)){
//						if (entry_type === "category"){
//							$entry.addClass("active menu-open");
//							$entry.find('li:first-child').addClass("active");
//						}else{
//							$entry.addClass("active");
//						}
//					}
				});// end _.each
			};
			return this;
		},

		isEntryVisible : function(entry) {
			var self = this;
	        var visible = "visible";
	        return !entry.hasOwnProperty(visible) || (entry.hasOwnProperty(visible) && (_.isFunction(entry[visible]) ? entry[visible].call(self) : (entry[visible] === true)) );
			
	    },
		render: function(){
			var self = this;
			this.$el.empty();
			//entries = entries || navdata;
			this.$el.html(template);
			var nav_list = this.$el.find('ul.sidebar-menu');
			this.loadEntries(nav_list, navdata, true);
			return this;
		},
		renderPoint: function(point_name){
			var self = this;
			this.$el.empty();
			//entries = entries || navdata;
			this.$el.html(template);
			var nav_list = this.$el.find('ul.sidebar-menu');
			
			var nav = $.extend(true, [], point_nav);
			for(var i = 0; i < nav.length; i++){
				if (
						!nav[i].hasOwnProperty("visible") || ((nav[i].hasOwnProperty("visible"))
						&& ( _.isFunction(nav[i].visible) ? nav[i].visible.call(self, point_name.point_name) : (nav[i].visible === true))) 
					){
					nav[i].route = gonrin.template(nav[i].route)(point_name);
					nav[i].visible = true;
				}else{
					nav[i].visible = false;
				}
			}
			this.loadEntries(nav_list, nav, true);
			
			//console.log("renderMerchant");
		},
		renderMerchant: function(merchant_id){
			var self = this;
			this.$el.empty();
			this.$el.html(template);
			var nav_list = this.$el.find('ul.sidebar-menu');
			
			var nav = $.extend(true, [], merchant_nav);
			for(var i = 0; i < nav.length; i++){
				nav[i].route = gonrin.template(nav[i].route)(merchant_id);
			}
			this.loadEntries(nav_list, nav, true);
		},
		handleEntryClick : function ($entry, entry) {
			var self = this;
			if(entry.type === "category"){
				var $a = $entry.children('a');
				if($a === undefined){
					return this;
				}
				$a.unbind("click").bind("click", function(e){
					self.$el.find(".sidebar-menu").children("li").removeClass("active");
		        	$(this).parents('li').addClass("active");
		        	var hasOpen = $(this).parents('li').hasClass('menu-open');
		        	if(!hasOpen){
		        		$(this).parents('li').addClass('menu-open');
		        		$(this).parents('li').children("ul").removeAttr("style");
		        	}else{
		        		$(this).parents('li').removeClass('menu-open');
		        		$(this).parents('li').children("ul").attr("style","display:none");
		        	}
		        });
			};
			if(entry.type === "view"){
				var $a = $entry.children('a');
				if($a === undefined){
					return this;
				}
				$a.unbind("click").bind("click", function(e){
					e.preventDefault();
					self.$el.find(".sidebar-menu").children("li").removeClass("active");
		            $(this).parents('li').addClass('active');
		            //if(entry.collectionName){
//		            	if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
//		            		 $('.menu-toggler').trigger("click");
//		            	}
		            self.getApp().getRouter().navigate(entry.route);
		            //}
				});
			};
	        return this;
	        
		},
	    
	});

});