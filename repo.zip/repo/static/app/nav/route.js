define(function (require) {
	"use strict";
	var $ = require('jquery'),
		_ = require('underscore'),
		Gonrin = require('gonrin');
	return [
		{
			"collectionName": "index",
			"route": "index",
			"$ref": "app/base/view/IndexView",
		},
		{
			"collectionName": "siem",
			"route": "siem/collection(/:id)",
			"$ref": "app/siem/view/siem",
		},
		{
			"collectionName": "user",
			"route": "user/collection(/:id)",
			"$ref": "app/user/user/view/CollectionView",
		},
		{
			"collectionName": "user",
			"route": "user/model(/:id)",
			"$ref": "app/user/user/view/ModelView",
		},
		{
			"collectionName": "role",
			"route": "role/collection(/:id)",
			"$ref": "app/user/role/view/CollectionView",
		},
		{
			"collectionName": "role",
			"route": "role/model(/:id)",
			"$ref": "app/user/role/view/ModelView",
		},
		
	];

});


