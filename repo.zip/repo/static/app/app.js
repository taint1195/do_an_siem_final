define('jquery', [], function() {
	
    return jQuery;
});

require.config({
    baseUrl: '/static/js/lib',
    paths: {
        app: '../../app',
        tpl: '../tpl',
        vendor: '../../vendor',
        schema: '../../schema'
    },
    shim: {
    	'gonrin': {
            deps: ['underscore', 'jquery', 'backbone'],
            exports: 'Gonrin'
        },
        'backbone': {
            deps: ['underscore', 'jquery'],
            exports: 'Backbone'
        },
        'underscore': {
            exports: '_'
        }
    }
});

require(['jquery', 'gonrin', 'app/router', 'app/nav/NavbarView','text!app/base/tpl/layout.html', 'i18n!app/nls/app', 'vendor/store'], function ($, Gonrin, Router, Nav, layout, lang, storejs) {
	$.ajaxSetup({
   	    headers: {
   	        'content-type':'application/json'
   	    }
   	});
	   
	   var storejs				= require('vendor/store');
	   
	var app = new Gonrin.Application({
		serviceURL: location.protocol+'//'+location.hostname+(location.port ? ':'+location.port : ''),
		router: new Router(),
		lang: lang,
		layout: layout,
		initialize: function(){
			this.getRouter().registerAppRoute();
			this.getCurrentUser();
		},
		getCurrentUser : function(){
			var self = this;
			token = storejs.get('X-USER-TOKEN')   
			$.ajax({
				url: self.serviceURL + '/api/v1/current_user',
				dataType:"json",
				
      		    headers: { 'X-USER-TOKEN': token },
       		    success: function (data) {
       		    	self.postLogin(data);
       		    },
       		    error: function(XMLHttpRequest, textStatus, errorThrown) {
       	            self.router.navigate("login");
       		    }
       		});
		},
		genId: function(salt){
    		var hashids = new Hashids(salt);
    		
    		var max = 10000, min=1;
    		var ranNum = Math.floor(Math.random() * (max - min + 1) + min);
    		var now = moment().unix();
    		var id = hashids.encode(now, ranNum);
    		return id;
    	},
		postLogin: function(data){
			var self = this;
			self.currentUser = new Gonrin.User(data);
			
			$('body').html(layout);
			this.$header = $('body').find(".navbar-custom-menu");
			this.$content = $('body').find(".content-wrapper");
			this.$navbar = $('body').find(".main-sidebar");
			this.$toolbox = $('body').find(".tools-area");
			
			this.nav = new Nav({el: this.$navbar});
			self.nav.render();
			this.nav.$el.find('ul.sidebar-menu li.current').first().find('a').click();

			
			$('body').find("#fullname").html(data.fullname);
			
			$("#logo").bind('click', function(){
				self.router.navigate("index");
            });
			
	    	$("#logout").bind('click', function(){
	    	    self.router.navigate("logout");
	    	});
	    	$("span#fullname").html(data.wallet_fullname);
	    	var current_params = self.router.currentRoute();

			if ((current_params["fragment"] === "") || (current_params["fragment"] === "login")) {
				self.router.navigate("index");
			}
	    	
		},
		
	});
    Backbone.history.start();
    
});