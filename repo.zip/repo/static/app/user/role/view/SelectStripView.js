define(function (require) {
    "use strict";
    var $ = require('jquery'),
        _ = require('underscore'),
        Gonrin = require('gonrin');

   
        var template 		= require('text!app/user/role/tpl/collection.html'),
    	schema 				= require('json!schema/RoleSchema.json');
        var TemplateHelper = require('app/Common/TemplateHelper');

    return Gonrin.CollectionDialogView.extend({
        //selectedItems : [],  //[] may be array if multiple selection
        template: template,
        modelSchema: schema,
        urlPrefix: "/api/v1/cms/",
        collectionName: "role",
        textField: "name",

        //valueField: "id",
        tools: [
            {
                name: "defaultgr",
                type: "group",
                groupClass: "toolbar-group",
                buttons: [
                    {
                        name: "select",
                        type: "button",
                        buttonClass: "btn-success btn-sm",
                        label: "TRANSLATE:SELECT",
                        command: function () {
                            var self = this;
                            self.trigger("onSelected");
                            self.close();
                        }
                    },
                ]
            },
        ],
        uiControl: {
            primaryField: "role_name",
            fields: [
                {
                    field: "_id", label: "ID", width: 250, readonly: true, visible: false
                },
                { field: "role_name", label: "Chức Năng", width: 250 },
                
                {
                    field: "description",
                    label: "Chú Thích", width: 250,
                },
                {
					field: "active", label: "Trạng thái", template: function (rowObj) {
						var tplHelper = new TemplateHelper();
						return tplHelper.statusRender(rowObj.active);
					}
				},


            ],
            onRowClick: function (event) {
                // console.log(event)  
                delete event.rowData['_id'];
                this.uiControl.selectedItems = event.selectedItems;
                // console.log(event.selectedItems);
                
            },
        },
        render: function () {
            if (!!this.viewData && !!this.viewData.filters) {
                this.uiControl.filters = this.viewData.filters;
            }
            this.applyBindings();
            return this;
        },
    });

});