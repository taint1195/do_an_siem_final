define(function (require) {
	"use strict";
	var $ = require('jquery'),
		_ = require('underscore'),
		Gonrin = require('gonrin');

	var template = require('text!app/user/role/tpl/model.html'),
		schema = require('json!schema/RoleSchema.json');

	return Gonrin.ModelView.extend({
		template: template,
		modelSchema: schema,
		urlPrefix: "/api/v1/cms/",
		collectionName: "role",

		uiControl: {
			fields: [
				{
					field: "active",
					uicontrol: "combobox",
					textField: "text",
					valueField: "value",
					dataSource: [
						{ "value": true, "text": "Active" },
						{ "value": false, "text": "Deactive" },
					],
				},
				{
					field: "role_name",
					uicontrol: "combobox",
					textField: "text",
					valueField: "value",
					dataSource: [
						{ "value": "ADMIN", "text": "ADMIN" },
						{ "value": "ACCOUNTING", "text": "ACCOUNTING" },
						{ "value": "TECHNICAL", "text": "TECHNICAL" },
					],
				},
			
			
			
			
			]

		},
		tools: [
			{
				name: "back",
				type: "button",
				buttonClass: "btn-default btn-sm margin-2",
				label: "TRANSLATE:BACK",
				command: function () {
					var self = this;
					self.getApp().getRouter().navigate("role/collection");
				}
			},
			{
				name: "save",
				type: "button",
				buttonClass: "btn btn-success btn-sm margin-2",
				label: "TRANSLATE:SAVE",
				command: function () {
					var self = this;
					
					if (true) {
					
						self.model.save(null, {
							success: function (model, respose, options) {
								self.getApp().getRouter().navigate(self.collectionName + "/collection");
								self.getApp().notify("Save successfully");
							},
							error: function (model, xhr, options) {
								//self.alertMessage("Something went wrong while processing the model", false);
								// self.getApp().notify('Save error');
								// console.log("dsadsad",$.parseJSON(xhr.responseText).message);
								self.getApp().notify($.parseJSON(xhr.responseText).message);
							}
						});
						
					}

				},
				visible: function(){
					return true;
					var user = gonrinApp().currentUser;
					var arr_roles = user.roles
					console.log(arr_roles);
					
					if (!!user) {
						for (var i = 0; i < arr_roles.length; i++) {
							
							if (roles[i] == "ADMIN") {
							
								return true;
							}
							return false;
						}
					}
					return false;
				}
			},
			{
				name: "delete",
				type: "button",
				buttonClass: "btn-danger btn-sm margin-2",
				label: "TRANSLATE:DELETE",
				visible: function () {
					return this.getApp().getRouter().getParam("id") ;
				},
				command: function () {
					var self = this;
					self.model.destroy({
						success: function (model, response) {
							self.getApp().notify('Delete Successfully!');
							self.getApp().getRouter().navigate("role/collection");
						},
						error: function (model, xhr, options) {
							self.getApp().notify('Delete error');
						}
					});
				}
			},
		],
		render: function () {
			var self = this;
			var id = self.getApp().getRouter().getParam("id");
			this.model.set('_id', id);
			
			if (id) {
				this.model.fetch({
					success: function (data) {
						self.applyBindings();
						
					},
					error: function () {
						self.getApp().notify("Get data Error");
					},
				});
			} else {
				
				self.applyBindings();

			}
			
		},
		validate: function () {
			var self = this;
			if ((self.model.get("role_name") || null) == null) {
				self.getApp().notify("role name is missing");
				return false;
			}
			if ((self.model.get("active") || null) == null) {
				self.getApp().notify("Trạng Thái is missing");
				return false;
			}
			return true;

		},
		
	});

});