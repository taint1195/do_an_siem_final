define(function (require) {
    "use strict";
    var $                   = require('jquery'),
        _                   = require('underscore'),
        Gonrin				= require('gonrin');
    
    var template 			= require('text!app/user/user/tpl/collection.html'),
    	schema 				= require('json!schema/UserSchema.json');
		var TemplateHelper = require('app/Common/TemplateHelper');
    return Gonrin.CollectionView.extend({
    	template : template,
    	modelSchema	: schema,
    	urlPrefix: "/api/v1/cms/",
		collectionName: "user",
    	tools:[
    	       {
					name: "create",
					type: "button",
					buttonClass: "btn-success btn-sm margin-2",
					label: "TRANSLATE:CREATE",
					command: function(){
						var self = this;
						self.getApp().getRouter().navigate(self.collectionName + "/model");

					}
				}
    	],
    	uiControl:{
    		fields: [
	    	    //  { 
	    	    // 	field: "_id",label:"ID",width:150,readonly: true, visible: false
	    	    //  },
	    	     { field: "full_name", label: "Tên Người Dùng"},
	    	     { field: "phone", label: "Số Điện Thoại"},
				 { field: "email", label: "Email"},
				 { field: "roles", label: "Chức năng", textField:"role_name"},
	    	    //  { field: "active", label: "Kích hoạt",
	    	    // 	 cssClassField: "cssClass",
	    	    // 	 foreignValues: [
				// 						{ value: true, text: "True" },
				// 						{ value: false, text: "False" },
		     	//                      ],
		     	//      foreignValueField: "value",
		     	//      foreignTextField: "text"
				 //  },
				 {
					field: "active", label: "Trạng thái", template: function (rowObj) {
						var tplHelper = new TemplateHelper();
						return tplHelper.statusRender(rowObj.active);
					}
				},
		     	     
		     ],
		     onRowClick: function(event){
		    	 var self = this;
		    	 if(event.rowData['_id']){
					 var path = this.collectionName + '/model?id='+ event.rowData['_id'];
					 this.getApp().getRouter().navigate(path);
		        }
		    }
    	},
	    render:function(){
    		var self = this;
	    	this.applyBindings();
	    	return this;
    	},
    });
  
});