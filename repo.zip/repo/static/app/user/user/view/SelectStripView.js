define(function (require) {
    "use strict";
    var $ = require('jquery'),
        _ = require('underscore'),
        Gonrin = require('gonrin');

   
        var template 		= require('text!app/user/user/tpl/collection.html'),
    	schema 				= require('json!schema/UserSchema.json');
    
    return Gonrin.CollectionDialogView.extend({
        //selectedItems : [],  //[] may be array if multiple selection
        template: template,
        modelSchema: schema,
        urlPrefix: "/api/v1/cms/",
        collectionName: "user",
        textField: "name",

        //valueField: "id",
        tools: [
            {
                name: "defaultgr",
                type: "group",
                groupClass: "toolbar-group",
                buttons: [
                    {
                        name: "select",
                        type: "button",
                        buttonClass: "btn-success btn-sm",
                        label: "TRANSLATE:SELECT",
                        command: function () {
                            var self = this;
                            self.trigger("onSelected");
                            self.close();
                        }
                    },
                ]
            },
        ],
        uiControl: {
            primaryField: "_id",
            fields: [
                {
                    field: "_id", label: "ID", width: 250, readonly: true, visible: false
                },
                { field: "name", label: "Tên Đẳng Nhập", width: 250 },
                
                {
                    field: "email",
                    label: "Email", width: 250,
                },
                


            ],
            onRowClick: function (event) {
                // console.log(event)
                this.uiControl.selectedItems = event.selectedItems;
            },
        },
        render: function () {
            if (!!this.viewData && !!this.viewData.filters) {
                this.uiControl.filters = this.viewData.filters;
            }
            this.applyBindings();
            return this;
        },
    });

});