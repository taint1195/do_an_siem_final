define(function (require) {
	"use strict";
	var $ = require('jquery'),
		_ = require('underscore'),
		Gonrin = require('gonrin');

	var template = require('text!app/user/user/tpl/model.html'),
		schema = require('json!schema/UserSchema.json');
	var RoleSelectView = require("app/user/role/view/SelectStripView")
	return Gonrin.ModelView.extend({
		template: template,
		modelSchema: schema,
		urlPrefix: "/api/v1/cms/",
		collectionName: "user",
		uiControl: {
			fields: [

				{
					field: "active",
					uicontrol: "combobox",
					textField: "text",
					valueField: "value",
					dataSource: [
						{ text: "Hoạt Động", value: true },
						{ text: "Không Hoạt Động", value: false }
					],
				},

				{
					field: "roles",
					label: "Chức Năng",
					uicontrol: "ref",
					textField: "role_name",
					selectionMode: "multiple",
					dataSource: RoleSelectView
				}

			]

		},
		tools: [
			{
				name: "back",
				type: "button",
				buttonClass: "btn-default btn-sm margin-2",
				label: "TRANSLATE:BACK",
				command: function () {
					var self = this;
					self.getApp().getRouter().navigate("user/collection");
				}
			},
			{
				name: "save",
				type: "button",
				buttonClass: "btn btn-success btn-sm margin-2",
				label: "TRANSLATE:SAVE",
				command: function () {
					var self = this;

					if (self.validate()) {

						self.model.save(null, {
							success: function (model, respose, options) {
								self.getApp().getRouter().navigate(self.collectionName + "/collection");
								self.getApp().notify("Save successfully");
							},
							error: function (model, xhr, options) {
								//self.alertMessage("Something went wrong while processing the model", false);
								// self.getApp().notify('Save error');
								// console.log("dsadsad",$.parseJSON(xhr.responseText).message);
								self.getApp().notify($.parseJSON(xhr.responseText).message);
							}
						});
						
					}

				},
				visible: function(){
					return true;
					var user = gonrinApp().currentUser;
					var arr_roles = user.roles
					if (!!user) {
						for (var i = 0; i < arr_roles.length; i++) {
							
							if (roles[i] == "ADMIN") {
							
								return true;
							}
							return false;
						}
					}
					return false;
				}
			},
			{
				name: "delete",
				type: "button",
				buttonClass: "btn-danger btn-sm margin-2",
				label: "TRANSLATE:DELETE",
				visible: function () {
					return this.getApp().getRouter().getParam("id");
				},
				command: function () {
					var self = this;
					self.model.destroy({
						success: function (model, response) {
							self.getApp().notify('Delete Successfully!');
							self.getApp().getRouter().navigate("user/collection");
						},
						error: function (model, xhr, options) {
							self.getApp().notify('Delete error');
						}
					});
				}
			},
		],
		render: function () {

			var self = this;
			var id = self.getApp().getRouter().getParam("id");
			this.model.set('_id', id);
			self.$el.find("#file-name").on('change', function (event) {
				
				
                var selectedFile = event.target.files[0];
                var size = selectedFile.size;
                var file_name = selectedFile.name;
                var type_of_file = file_name.split(".")[1];

                // Validate file
                if (size <= 10000000) {
                    if (type_of_file === "png" || type_of_file === "jpg") {
                        self.upload(selectedFile);
                    }
                    else {
                        self.getApp().notify("File không đúng định dạng, vui lòng chọn file có dạng: PNG hoặc JPG!.");
                    }
                }
                else {
                    self.getApp().notify("File có size quá lớn, vui lòng chọn file nhỏ hơn!.");
                }
            });
			if (id) {
				this.model.fetch({
					success: function (data) {
						var profile_image_url = self.model.get('profile_image_url');
						self.$el.find("#image_view").attr("src", profile_image_url);
						self.$el.find('#user_name').attr('readonly', true);
						self.$el.find('#password').attr('readonly', true);
						self.$el.find('#confirm_password').attr('readonly', true);
						self.applyBindings();
					},
					error: function () {
						self.getApp().notify("Get data Error");
					},
				});
			} else {
				self.applyBindings();
			}
		},
		validate: function () {
			var self = this;
			if (self.model.get("phone")  == null) {
				self.getApp().notify("Phone number is missing");
				return false;
			}
			
			if (self.model.get("user_name")  == null) {
				self.getApp().notify("User name is missing");
				return false;
			}
			if (self.model.get("email")  == null) {
				self.getApp().notify("email is missing");
				return false;
			}
			if (self.model.get("roles")  == null) {
				self.getApp().notify("Roles is missing");
				return false;
			}
			return true;

		},
		upload: function (selectedFile) {
            var self = this;
            var url = self.getApp().serviceURL + "/api/v1/cms/image/upload";

            // Upload image to server
            //make form object with specific enctype
            var form = document.createElement('form');
            form.enctype = "multipart/form-data";

            //FormData object to store all form key/values
            var formData = new FormData(form);
            //append file data
            if (selectedFile) {
                var file_name = selectedFile.name;
                formData.append('file', selectedFile, file_name);
            }

            var request = new XMLHttpRequest();
            request.onreadystatechange = function () {
                if (request.readyState === XMLHttpRequest.DONE) {
                    var res = JSON.parse(request.responseText);
                    if (res['error_code'] === 200) {
                        var image_link = res['error_message'];
                        self.model.set("profile_image_url", image_link);
                        
                        // Render image
                        var reader = new FileReader();
                        var imgtag = document.getElementById("image_view");
                        imgtag.title = selectedFile.name;
                        reader.onload = function (event) {
                            imgtag.src = event.target.result;
                        };
                        reader.readAsDataURL(selectedFile);
                        self.getApp().notify("Hình ảnh của bạn đã được cập nhật thành công!.");
                    }
                    else {
                        self.getApp().notify("Cập nhật hình ảnh lỗi. Vui lòng thử lại sau!.");
                    }
                }
            };
            request.open("POST", url);
            request.send(formData);
        }



	});

});