

// define(function (require) {

//     "use strict";
//     var $ = require('jquery'),
//         _ = require('underscore'),
//         Gonrin = require('gonrin');



//     var template = require('text!app/user/user/tpl/dialog_change_pass.html'),
//         schema = require('json!schema/DialogsyncSchema.json');

//     var View_Item_Type_Id = require('app/config_item_ihub/view/ItemTypeSelectStripView');
//     var ItemEatWithSelectStripView = require('app/config_item_ihub/view/ItemEatWithSelectStripView');

//     var currencyFormat = {
//         symbol: "",		// default currency symbol is '$'
//         format: "%v",	// controls output: %s = symbol, %v = value (can be object, see docs)
//         decimal: ".",		// decimal point separator
//         thousand: ",",		// thousands separator
//         precision: 0,		// decimal places
//         grouping: 3		// digit grouping (not implemented yet)
//     };
//     return Gonrin.ModelDialogView.extend({
//         template: template,
//         modelSchema: schema,
//         // urlPrefix: "",
//         collectionName: "",

//         uiControl: {
//             fields: [

//                 {
//                     field: "dm_sync",
//                     uicontrol: "combobox",
//                     textField: "text",
//                     valueField: "value",
//                     dataSource: [
//                         { "value": null, "text": "Đồng bộ tất cả" },
//                         { "value": "DM_ITEM", "text": "Đồng bộ món" },
//                         { "value": "DM_ITEM_TYPE", "text": "Động bộ nhóm món" },
//                         { "value": "DM_ITEM_PACKAGE", "text": "Đồng bộ combo 1" },
//                         { "value": "PACKAGE2_MANAGER", "text": "Đồng bộ combo 2" },
//                         { "value": "SYNC_ITEM_V2", "text": "Đồng bộ Item_v2" }
//                     ]
//                 },
//                 {
//                     field: "Active",

//                     uicontrol: "checkbox",
//                     checkedField: "key",
//                     valueField: "value",
//                     dataSource: [
//                         {
//                             "value": 1,
//                             "key": true
//                         },
//                         {
//                             "value": 0,
//                             "key": false
//                         },
//                     ],
//                 },


//             ]
//         },
//         tools: [

//         ],
//         preproces_sync: function () {
//             var self = this;
//             var url = self.getApp().serviceURL + '/api/v1/cms/sync_data_from_pos'
//             var sync_dm_pos_ihub = self.$el.find('#sync_dm_pos_ihub');


//             sync_dm_pos_ihub.unbind("click").bind("click", function () {
//                 let pos_parent = self.model.get('pos_parent');
//                 let pos_id = self.model.get('pos_id');
//                 let dm_sync = self.model.get('dm_sync');

//                 var data_req = {
//                     "pos_parent": pos_parent,
//                     "pos_id": pos_id,
//                     "dm_sync": dm_sync
//                 }
//                 if (dm_sync != "SYNC_ITEM_V2") {
//                     $.ajax({
//                         url: url,
//                         data: JSON.stringify(data_req),
//                         method: "POST",
//                         contentType: "application/json",
//                         beforeSend: function () {
//                             self.$el.find("#loading").show();
//                         },
//                         success: function (data) {
//                             // self.getApp().getRouter().navigate("user/collection");

//                             self.getApp().trigger("dm_sync_ihub_closed")
//                             self.getApp().notify("sync success");
//                             self.$el.find("#loading").hide();
//                             self.close();
//                         },
//                         error: function (xhr, status, error) {
//                             // console.log(xhr, status, error);
//                             self.$el.find("#loading").hide();
//                             self.getApp().notify(xhr['responseJSON']['message']);
//                             self.close();
//                         },
//                     });
//                 }else{
//                     var url_v2 = self.getApp().serviceURL + '/api/v1/cms/sync_data_item_v2'
//                     $.ajax({
//                         url: url_v2,
//                         data: JSON.stringify(data_req),
//                         method: "POST",
//                         contentType: "application/json",
//                         beforeSend: function () {
//                             self.$el.find("#loading").show();
//                         },
//                         success: function (data) {
//                             // self.getApp().getRouter().navigate("user/collection");

//                             self.getApp().notify("sync item v2 success");
//                             self.$el.find("#loading").hide();
//                             self.close();
//                         },
//                         error: function (xhr, status, error) {
//                             // console.log(xhr, status, error);
//                             self.$el.find("#loading").hide();
//                             self.getApp().notify(xhr['responseJSON']['message']);
//                             self.close();
//                         },
//                     });
//                 }
//             });

//         },
//         process_delete_menu: function (pos_id) {

//             var self = this;
//             var url = self.getApp().serviceURL + '/api/v1/cms/remove_menu_ihub?pos_id=' + pos_id
//             var delete_menu = self.$el.find('#delete_menu');

//             delete_menu.unbind("click").bind("click", function () {
//                 $.ajax({
//                     url: url,
//                     method: "GET",
//                     beforeSend: function () {
//                         self.$el.find("#loading").show();
//                     },
//                     success: function (data) {
//                         // self.getApp().getRouter().navigate("user/collection");

//                         self.getApp().trigger("delete_menu_ihub_closed")
//                         self.getApp().notify("delete menu success");
//                         self.$el.find("#loading").hide();
//                         self.close();
//                     },
//                     error: function (xhr, status, error) {
//                         // console.log(xhr, status, error);
//                         self.$el.find("#loading").hide();
//                         self.getApp().notify(xhr['responseJSON']['message']);
//                         self.close();
//                     },
//                 });
//             });
//         },
//         render: function () {
//             var self = this;


//             var pos_id = self.viewData['pos_id'];
//             var pos_parent = self.viewData['pos_parent'];
//             var option = self.viewData['option'];
//             self.model.set('dm_sync', null);
//             if (pos_id) {
//                 self.model.set('pos_id', pos_id);
//                 self.model.set('pos_parent', pos_parent);
//                 if (option == "sync") {
//                     self.$el.find('#sync_dm_pos_ihub').show();
//                     self.preproces_sync();
//                 }
//                 if (option == "delete_menu") {
//                     self.$el.find('#delete_menu').show();
//                     self.$el.find('#method_sync').attr('readonly', true);
//                     self.process_delete_menu(pos_id);
//                 }

//                 self.applyBindings();
//             } else {
//                 self.applyBindings();

//             }



//         },

//     });

// });