define({
    "root": {
        "CREATE": "Tạo mới",
        "EDIT": "Sửa",
        "SAVE": "Lưu",
        "BACK": "Quay lại",
        "DELETE": "Xoá",
        "SELECT": "Chọn",
        "CANCEL": "Huỷ",
        "SYNC": "Đồng bộ",
        "NO_RECORDS_FOUND":"Chưa có dữ liệu"
    }
});