define(function (require) {
	"use strict";
	var $ = require('jquery'),
		_ = require('underscore'),
		Gonrin = require('gonrin');

	var template = require('text!app/base/tpl/index/index.html');
	

	return Gonrin.View.extend({
		template: template,
		collectionName: "index",
		tools: [],
		render: function () {
			var self = this;
			//console.log("index");
			
			//self.fetchPoints();
			self.registerEvents();
			self.get_report();
			self.getApp().nav.render();
		},

		registerEvents: function () {
			var self = this;
			
			
			
		},
		get_report: function () {
			var self = this;
		
		}


	});

});