// define(function (require) {
// 	"use strict";
// 	var $ = require('jquery'),
// 		_ = require('underscore'),
// 		Gonrin = require('gonrin');

// 	var template = require('text!app/base/tpl/layout.html');


// 	return Gonrin.View.extend({
// 		template: template,
// 		collectionName: "index",
// 		tools: [],
// 		render: function () {
// 			var self = this;
// 			//console.log("index");
//             var user = self.getApp().currentUser;
//             console.log(user);
            
// 			if (!!user) {
				
                

// 			}
			
// 			self.getApp().nav.render();
// 		},

// 		registerEvents: function () {
// 			var self = this;
// 			self.$el.find("#create-point").unbind("click").bind("click", function () {
// 				if (!!user && (user.role === "admin")) {
// 					self.getApp().router.navigate("point/model");
// 				}
// 			});
// 			self.$el.find("#create-merchant").unbind("click").bind("click", function () {
// 				if (!!user && (user.role === "admin")) {
// 					self.getApp().router.navigate("merchant/model");
// 				}
// 			});
			
			
// 		},
		


// 	});

// });