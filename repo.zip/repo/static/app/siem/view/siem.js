
define(function (require) {

	"use strict";
	var $ = require('jquery'),
		_ = require('underscore'),
		Gonrin = require('gonrin');


	var template = require('text!app/siem/tpl/model.html'),
		schema = require('json!schema/siem.json');


	var currencyFormat = {
		symbol: "",		// default currency symbol is '$'
		format: "%v",	// controls output: %s = symbol, %v = value (can be object, see docs)
		decimal: ".",		// decimal point separator
		thousand: ",",		// thousands separator
		precision: 0,		// decimal places
		grouping: 3		// digit grouping (not implemented yet)
	};

	var search_data = []
	return Gonrin.ModelView.extend({
		template: template,
		modelSchema: schema,
		urlPrefix: "/api/v1/cms/",
		collectionName: "siem",

		uiControl: {
			fields: [

				{
					field: "type_check",
					uicontrol: "combobox",
					textField: "text",
					valueField: "value",
					dataSource: [
						{ "value": "ung_dung", "text": "Ứng Dụng Regix Phân Tích Log" },
					]
				},
				{
					field: "all",

					uicontrol: "checkbox",
					checkedField: "key",
					valueField: "value",
					dataSource: [{
						"value": 1,
						"key": true
					},
					{
						"value": 0,
						"key": false
					},
					],
				},
				{
					field: "xss",

					uicontrol: "checkbox",
					checkedField: "key",
					valueField: "value",
					dataSource: [{
						"value": 1,
						"key": true
					},
					{
						"value": 0,
						"key": false
					},
					],
				},
				{
					field: "sql",

					uicontrol: "checkbox",
					checkedField: "key",
					valueField: "value",
					dataSource: [{
						"value": 1,
						"key": true
					},
					{
						"value": 0,
						"key": false
					},
					]
				},{

					field: "traversal",

					uicontrol: "checkbox",
					checkedField: "key",
					valueField: "value",
					dataSource: [{
						"value": 1,
						"key": true
					},
					{
						"value": 0,
						"key": false
					},
					]
				}


			]

		},
		tools: [
			{
				name: "lookups",
				type: "button",
				buttonClass: "btn btn-primary btn-sm margin-2",
				label: "TRANSLATE:Phân Tích",
				command: function () {
					var self = this;

					var base_url = self.getApp().serviceURL + '/api/v1/cms/siem';

					var data = {

						"xss": self.model.get('xss'),
						"sql": self.model.get('sql'),
						"traversal": self.model.get('traversal'),
					}
					self.siem(base_url, data);



				}
			},
			{
				name: "lookups2",
				type: "button",
				buttonClass: "btn btn-warning btn-sm margin-2",
				label: "TRANSLATE: Cảnh Báo",
				command: function () {
					var self = this;

					var email = prompt("Nhập email người nhận báo cáo:");
					var check_email = self.validate_email(email);

					if (check_email === true) {
						email = email.trim().toUpperCase();
						var base_url = self.getApp().serviceURL + '/api/v1/cms/send_email_siem';

						var data = {

							"xss": self.model.get('xss'),
							"sql": self.model.get('sql'),
							"traversal": self.model.get('traversal'),
							"email":email
						}
						self.send_email(data, base_url);

					} else {
						self.getApp().notify('Email không hợp lệ !!!');
					}

				}
			},

		],
		render: function () {
			var self = this;


			var base_url = self.getApp().serviceURL + '/api/v1/cms/siem';

			var data = {

				"xss": self.model.get('xss'),
				"sql": self.model.get('sql'),
				"traversal": self.model.get('traversal'),
			}

			self.siem(base_url, data);

			self.applyBindings();




		},
		validate_email: function (email) {
			var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(String(email).toLowerCase());
		},
		send_email: function (data, url) {
			var self = this;
			$.ajax({
				url: url,
				data: JSON.stringify(data),
				method: "POST",
				contentType: "application/json",
				beforeSend: function () {
					self.$el.find("#loading").show();
				},
				success: function (data) {
					self.$el.find("#loading").hide();
					self.getApp().notify("send mail success!!!");
				},
				error: function (xhr, status, error) {
					self.$el.find("#loading").hide();
					self.getApp().notify("send mail error!!!");
				},
			});
		},
		validate: function () {

			return true;

		},
		siem: function (url, data_param) {
			var self = this;
			self.$el.find("#context_grid").empty();

			$.ajax({
				url: url,
				data: JSON.stringify(data_param),
				method: "POST",
				contentType: "application/json",
				beforeSend: function () {
					self.$el.find("#loading").show();
				},
				success: function (data) {

					self.$el.find("#context_grid").grid({
						refresh: true,

						dataSource: data['data'],
						fields: [
							{ field: "HOST", label: "HOST" },
							{ field: "TIME", label: "TIME" },

							{ field: "STATUS", label: "STATUS" },
							{ field: "SIZE", label: "SIZE" },
							{ field: "DETECT", label: "DETECT" },
							// { field: "REQUEST", label: "REQUEST" },
							{
								field: " ", label: " ",
								command: [
									{
										"label": "VIEW REQUEST",
										"action": function (params) {
											console.log(params);
											self.model.set('view_json', JSON.stringify(params['rowData']['REQUEST'], undefined, 4))

											$('#view_json').show();
											$('.wrapper').animate({ scrollTop: $('#view_json').position().top }, 'slow');


										},
										"class": "btn-primary btn-xs"
									},
								],
							},

						]
					})
					self.$el.find('#context_grid').show();
					// 
					// $("#context_partition").pagination({
					// 	refresh: true,
					// 	page: self.model.get('page'),
					// 	pageSize: pageSize,
					// 	totalPages: total_page,
					// });
					// $('#context_partition').show();


					self.$el.find("#loading").hide();
				},
				error: function (xhr, status, error) {
					// self.model.set('total_row_data', '0')
					// $('#search_item').hide();
					// $('#context_grid_item').empty();
					self.$el.find("#loading").hide();
					self.getApp().notify("loi phan tich data!!!");
				},
			});
		}
	});

});