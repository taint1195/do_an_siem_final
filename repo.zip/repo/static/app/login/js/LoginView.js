define(function (require) {

	"use strict";
	var $ = require('jquery'),
		_ = require('underscore'),
		Gonrin = require('gonrin'),
		storejs = require('vendor/store'),
		tpl = require('text!app/login/tpl/login.html'),
		template = _.template(tpl);
	return Gonrin.View.extend({
		render: function () {
			var self = this;
			this.$el.html(template());

			$("#register-btn").bind('click', function () {
				if (qrcode !== undefined && qrcode !== null && qrcode !== "") {
					self.getApp().getRouter().navigate("dangky?qr=" + qrcode);
				} else {
					self.getApp().getRouter().navigate("dangky");
				}

			});
			$("#forget-password").bind('click', function () {
				self.getApp().getRouter().navigate("forgot");
			});


			this.$el.find("#login-form").unbind("submit").bind("submit", function () {
				self.processLogin();
				return false;
			});
			return this;
		},
		processLogin: function () {
			var self = this;

			var user = this.$('[name=data]').val();
			var password = this.$('[name=password]').val();


			var data = JSON.stringify({
				username: user,
				password: password
			});

			$.ajax({
				url: self.getApp().serviceURL + "/api/v1/login",
				type: 'post',
				data: data,
				headers: {
					'content-type': 'application/json'
				},
				beforeSend: function () {
					$("#loading").removeClass("hidden");
				},
				complete: function () {
					$("#loading").addClass("hidden");
				},
				dataType: 'json',
				success: function (data) {
					console.log("data :" + data)
					$.ajaxSetup({
						headers: {
							'X-USER-TOKEN': data.token
						}
					});
					storejs.set('X-USER-TOKEN', data.token);
					//       		    	self.getApp().postLogin(data);
					self.getApp().getCurrentUser();
					if (password === undefined || password === "") {
						self.router.navigate("user/profile");
					}
				},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
					self.getApp().notify("Login error");
				}
			});
		},

	});

});