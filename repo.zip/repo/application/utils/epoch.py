from datetime import datetime, timedelta
import time

def from_epoch(epoch):
    start_epoch = datetime(1970, 1, 1)
    return start_epoch + timedelta(seconds=(epoch))

def to_epoch(dat):
    tzoffset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
    print ("to_epoch", tzoffset)
    start_epoch = datetime(1970, 1, 1)
    return (dat - start_epoch).total_seconds() + tzoffset

def current_epoch():
    #tzoffset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
    epoch = to_epoch(datetime.now())
    return epoch
    