import time
from gatco.response import json,text, html
from application.extensions import apimanager
from application.extensions import auth
from application.server import app
from gatco.exceptions import ServerError
from application.database import motordb
from gatco_restapi.helpers import to_dict
import random, string
from bson.objectid import ObjectId
from test.support import _id
from application.config import Config
from math import floor
from datetime import datetime


config = Config()

def auth_func(**kw):
    pass


def generate_salt():
    code = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(32))
#     print (code)
    return code

     
async def set_user_passwd(data=None,**kw):
  
    if (data is not None) and ('password' in data) and ('confirm_password' in data):
        
        if(data['password']  == data['confirm_password']):
#             print("-----------", data['password'])
            data['salt'] = generate_salt()
            data['password'] = auth.encrypt_password(data['password'], data['salt'])  
                 
            del data['confirm_password']
            
            return data
        else:
            return json({"error_code": "PARAM_ERROR", "error_message":"Confirm password is not match"},status=520)
     
    return json({"error_code": "PARAM_ERROR", "error_message":"Parameters are not correct"},status=520)
         
async def pre_post_user(data, **kw):
    
    if  ('email' in data) and ('phone' in data) and ('user_name' in data) :
        users = motordb.db['user'].find({ '$or': [
             {'user_name': data["user_name"]}, 
             {'phone': data["phone"]}, 
             {'email': data["email"]}
            ]})
        
        async for user in users:
            if user is not None:
#                 print(user["_id"])
                print("user existed!!!!!!!!!!!!!!!!!!!!!!!")
                return json({"error_code":"USER_EXISTED","error_message":'Email or Account or Phone existed'},status=520)
        return data
    else:
        return json({"error_code":"PARRAM_ERROR","error_message":'parameter is incorrect'},status=520)
    
async def pre_put_user(instance_id = None, data = None, **kw):

    users = motordb.db['user'].find({'_id': ObjectId(instance_id)})
    async for user in users:
        if user is not None and "password" in user and "salt" in user :
            password = 'password'
            data['password'] = user["password"]
            data['salt'] = user["salt"]


async def postprocess_user(result, **kw):
    if "password" in result and "salt" in result:
        del result['password']
        del result['salt'] 
    
async def postprocess_get_many_user(result, **kw):
    users= []
    for item in result["objects"]:
        if "password" in item and "salt" in item:
            del item["password"]
            del item["salt"]
        users.append(item)
        
    result["objects"]= users;


@app.route('/api/v1/login', methods=['POST'])
async def login(request):
    username = request.json.get("username", None)
    password = request.json.get("password", None)
    
    users = motordb.db['user'].find({'user_name': username})
    
    async for user in users:
        
        if (user is not None) and auth.verify_password(password, user["password"], user["salt"]):
            history_login = {}
            history_login['user_name'] = username
            history_login['email'] = user['email']
            history_login['full_name'] = user['full_name']
            history_login['phone'] = user['phone']
            history_login['roles'] = user['roles']
            
            del user['salt']
            del user['password']
            del user['_id']
            return json(get_detail_user_info(user))
        
    return json({"error_code":"LOGIN_FAILED", "error_message":"User does not exist or incorrect password"}, status=520)

def get_detail_user_info(user):
    if user is not None:
        user_info = to_dict(user)
        return user_info
    return None


@app.route('/api/v1/logout')
def logout(request):
    try:
        auth.logout_user(request)
    except:
        pass
    return json({})

# @app.route('/api/v1/current_user')
# async def current_user(request):
#     if uid is not None:
#         user = await motordb.db['user'].find_one({ "email":ObjectId(uid) })
#         return user
#     return json({
#         "error_message":"USER_NOT_FOUND"
#     }, status = 520)



@app.route('/api/v1/current_user')
async def get_current_user(request):
    return json({
        "error_message":"admin"
    }, status = 200)

@auth.serializer
def serializer(user):
    userobj = to_dict(user)
    userobj["exprire"] = time.time() + auth.expire
#     del userobj["_id"]
    userobj["_id"] = str(ObjectId(userobj['_id']))

    return userobj

@auth.user_loader
def user_loader(token):
    if token is not None:
        if 'exprire' in token:
            if token['exprire'] < time.time():
                return None
            del(token["exprire"])
        return token
    return None

apimanager.create_api(collection_name='user',
    methods=['GET', 'POST', 'DELETE', 'PUT'],
    url_prefix='/api/v1/cms',
    preprocess=dict(GET_SINGLE=[auth_func],
                    GET_MANY=[auth_func],
                    POST=[auth_func, pre_post_user, set_user_passwd ],
                    PUT_SINGLE=[auth_func, pre_put_user]),
    postprocess=dict(
        POST=[auth_func , postprocess_user],
        GET_MANY=[auth_func, postprocess_get_many_user],
        GET_SINGLE=[auth_func, postprocess_user],
        PUT = [auth_func, postprocess_user] 
    ),
    exclude_columns = ['user_password'])


apimanager.create_api(collection_name='role',
    methods=['GET', 'POST', 'DELETE', 'PUT'],
    url_prefix='/api/v1/cms',
    preprocess=dict(GET_SINGLE=[auth_func],
                    GET_MANY=[auth_func],
                    POST=[auth_func ],
                    PUT_SINGLE=[auth_func]),
    postprocess=dict(
        POST=[auth_func ],
        GET_MANY=[auth_func],
        GET_SINGLE=[auth_func],
        PUT = [auth_func] 
    ))
        