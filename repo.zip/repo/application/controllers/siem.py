import time
from gatco.response import json
from application.server import app
from math import floor
from datetime import datetime
import re

import pandas as pd
import os
import smtplib, ssl
import datetime
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 


HOST = r'^.*\-\w{3}\s+(?P<host>.*)'
SPACE = r'\s'
IDENTITY = r'\S+'
USER = r'\S+'
TIME = r'(?P<time>\[.*?\])'
REQUEST = r'\"(?P<request>.*?)\"'
STATUS = r'(?P<status>\d{3})'
SIZE = r'(?P<size>\S+)'


path = 'application/reverse_proxy/'

HOST
REGEX_FILE = HOST+SPACE+IDENTITY+SPACE+USER+SPACE+TIME+SPACE+REQUEST+SPACE+STATUS+SPACE+SIZE+SPACE

REGEX_REQUEST_XSS = r'.*(?P<XSS>(?:GET|POST|PUT).*(?:s|S)cript.*(?:s|S)cript.*)'
REGEX_REQUEST_SQL = r'.*(?P<SQL>(?:union.*select.*)|(?:select.*where.*))'
REGEX_REQUEST_TRAVERSAL_PATH=r'.*(?P<TRAVERSAL>.*(?:\/..\/..\/|\/|\\|..\\|..\/)(?:etc|home|passwd).*)'
# REGEX_REQUEST_TRAVERSAL_PATH=r'.*(?<TRAVERSAL>\/etc.*)'


@app.route('/api/v1/cms/siem', methods=["POST", "OPTION"]) # tao API( door) cho frontend query vao
async def siem(request):
    data = request.json
    xss = data.get('xss', None) # get gia tri tu parameter vao  {0,1  (body cua json) }
    sql = data.get('sql', None)
    traversal = data.get('traversal', None)
   
    df = get_all_log( xss, sql, traversal)    # ham lay log tu thu muc va do vaof df
    #print(df, type(df))
    data_resp=[]
    if df.empty != True:
        data_resp = df.T.to_dict().values()
    
    return json({"data": data_resp}, status =200)


@app.route('/api/v1/cms/send_email_siem', methods=["POST", "OPTION"])
async def send_email_siem(request):
    data = request.json
    xss = data.get('xss', None)
    sql = data.get('sql', None)
    traversal= data.get('traversal', None)
    toaddr = data.get('email', None)
    path_file = get_all_log_to_send_mail(xss, sql,traversal)
   
        
    fromaddr = 'banhmysv@gmail.com'
    
       
    msg = MIMEMultipart() 
    msg['From'] = fromaddr 
       
    msg['To'] = toaddr 
      
    msg['Subject'] = "Cảnh Báo Tử Admin"
      
    body = "WARM PHAT HIEN TAN CONG "
    
    msg.attach(MIMEText(body, 'plain')) 

    if path_file is not None:
        filename = "phan_tich_log"
        attachment = open(path_file, "rb") 
          
        p = MIMEBase('application', 'octet-stream') 
          
        p.set_payload((attachment).read()) 
          
        encoders.encode_base64(p) 
       
        p.add_header('Content-Disposition', "attachment; filename= %s" % filename) 
      
        msg.attach(p) 
      
    s = smtplib.SMTP('smtp.gmail.com', 587) 
      
    s.starttls() 
      
    s.login(fromaddr, "24081996Ad") 
      
    text = msg.as_string() 
      
    s.sendmail(fromaddr, toaddr, text) 
      
    s.quit() 
    
    return json({"message": "send done"}, status =200)


def parser_file(log_line):
    match = re.search(REGEX_FILE, log_line)
    return ( (match.group('host'),

            match.group('time'), 
                      match.group('request') , 
                      match.group('status') ,
                      match.group('size')
                     )
                   )


#Ham xu ly xss,sql

def parser_request_xss(req):
    # print(req)
    try:
        match = re.search(REGEX_REQUEST_XSS, req)
        if match is not None:
            return match.group('XSS')
        return False

    except Exception as e:
        # print(e)
        return False
        
def parser_request_traversal(req):
    try:
        match = re.search(REGEX_REQUEST_TRAVERSAL_PATH, req)
        if match is not None:
            return match.group('TRAVERSAL')
        return False

    except Exception as e:
        print(e)
        return False



def parser_request_sql(req):
    # print(req)
    try:
        match = re.search(REGEX_REQUEST_SQL, req)
        if match is not None:
            
            return match.group('SQL')
        return False

    except Exception as e:
        # print(e)
        return False
        

def process_log(PATH_FILE, **kw):
    arr =[]
    with open(PATH_FILE,'r') as f:
        for line in f:
            result = parser_file(line)
            arr.append(result)
            
    df = pd.DataFrame(arr, columns=['HOST','TIME','REQUEST','STATUS','SIZE'])
    

    process_data_regex(df)


def get_all_log(xss, sql, traversal):
    arr =[]
    
    files = []
    for r, d, f in os.walk(path):
       
        for file in f:
            files.append(os.path.join(r, file))
            
    
    for path_file in files:
        with open(path_file,'r') as f:
            for line in f:
                result = parser_file(line) # parsing truong` match group
                arr.append(result)
    
    
    
    df = pd.DataFrame(arr, columns=['HOST','TIME','REQUEST','STATUS','SIZE']) # tra ve mot data frame
    
    
    if xss == 0 and sql == 0 and traversal == 0:
        return df
    else:
        return process_data_regex(xss, sql, traversal, df)
        
def process_data_regex(xss, sql, traversal, data_frame):


    try:
        file_name = str('application/export_report/'+str(datetime.datetime.now()))+'export_data.csv'
            
        if xss == 1 and sql ==0 and traversal == 0:
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else False)
            data_frame_resp = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            return data_frame_resp
        
        if xss == 0 and sql ==1  and traversal == 0:
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_SQL" if parser_request_sql(str_req) else False)
            data_frame_resp = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            return data_frame_resp
            
        if xss == 0 and sql ==0  and traversal == 1:

            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_TRAVERSAL_PATH" if parser_request_traversal(str_req) else False)
            data_frame_resp = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            return data_frame_resp
            
        if xss == 1 and sql ==1 and traversal == 0:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else ('TAN_CONG_SQL' if parser_request_sql(str_req) else False))
            data_frame_resp = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
        
            return data_frame_resp

            
        if xss == 1 and sql ==0 and traversal == 1:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else ('TAN_CONG_TRAVERSAL_PATH' if parser_request_traversal(str_req) else False))
            data_frame_resp = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
        
            return data_frame_resp

            
        if xss == 0 and sql ==1 and traversal == 1:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_SQL" if parser_request_sql(str_req) else ('TAN_CONG_TRAVERSAL_PATH' if parser_request_traversal(str_req) else False))
            data_frame_resp = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
        
            return data_frame_resp


        if xss == 1 and sql ==1 and traversal == 1:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else ('TAN_CONG_SQL' if parser_request_sql(str_req) else ('TAN_CONG_TRAVERSAL_PATH' if parser_request_traversal(str_req) else False)))
            data_frame_resp = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
        
            return data_frame_resp

        
  
            
    except Exception as e:
        print("error", e)
  


def get_all_log_to_send_mail(xss, sql,traversal):
    arr =[]
    
    files = []
    for r, d, f in os.walk(path):
       
        for file in f:
          
            files.append(os.path.join(r, file))
    
    
    for path_file in files:
#         print("path_file: ", path_file)
#         process_log(path_file)
        with open(path_file,'r') as f:
            for line in f:
                result = parser_file(line)
                arr.append(result)
    
    
    
    df = pd.DataFrame(arr, columns=['HOST','TIME','REQUEST','STATUS','SIZE'])
    
    
    if xss == 0 and sql == 0 and traversal==0:
        return None
    else:
        return process_data_regex_to_send_mail(xss, sql, traversal, df)


def process_data_regex_to_send_mail(xss, sql, traversal,data_frame):


    try:
        file_name = str('application/export_report/'+str(datetime.datetime.now()))+'export_data.csv'
            
        if xss == 1 and sql ==0 and traversal == 0:
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else False)
            data_frame_csv = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            data_frame_csv.to_csv(file_name)
            return file_name
        
        if xss == 0 and sql ==1  and traversal == 0:
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_SQL" if parser_request_sql(str_req) else False)
            data_frame_csv = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            data_frame_csv.to_csv(file_name)
            return file_name
            
        if xss == 0 and sql ==0  and traversal == 1:

            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_TRAVERSAL_PATH" if parser_request_traversal(str_req) else False)
            data_frame_csv = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            data_frame_csv.to_csv(file_name)
            return file_name
            
        if xss == 1 and sql ==1 and traversal == 0:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else ('TAN_CONG_SQL' if parser_request_sql(str_req) else False))
            data_frame_csv = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            data_frame_csv.to_csv(file_name)
            return file_name
            
        if xss == 1 and sql ==0 and traversal == 1:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else ('TAN_CONG_TRAVERSAL_PATH' if parser_request_traversal(str_req) else False))
            data_frame_csv = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            data_frame_csv.to_csv(file_name)
            return file_name
            
        if xss == 0 and sql ==1 and traversal == 1:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_SQL" if parser_request_sql(str_req) else ('TAN_CONG_TRAVERSAL_PATH' if parser_request_traversal(str_req) else False))
            data_frame_csv = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            data_frame_csv.to_csv(file_name)
            return file_name


        if xss == 1 and sql ==1 and traversal == 1:
            print ("data_frame_resp")
            data_frame['DETECT'] = data_frame['REQUEST'].apply(lambda str_req: "TAN_CONG_XSS" if parser_request_xss(str_req) else ('TAN_CONG_SQL' if parser_request_sql(str_req) else ('TAN_CONG_TRAVERSAL_PATH' if parser_request_traversal(str_req) else False)))
            data_frame_csv = data_frame.loc[lambda data_frame: data_frame['DETECT'] != False] 
            data_frame_csv.to_csv(file_name)
            return file_name

        
    
    except Exception as e:
        print("error", e)
