from application.extensions import jinja
from gatco.response import json

def init_controllers(app):
    import application.controllers.user
    import application.controllers.siem
    
    
    @app.route('/')
    def index(request):
        # return jinja.render_string('Hello {{name}}', request, {"name": "CuongNC"})
        return jinja.render('index.html', request)

    @app.route('/block')
    def block(request):
        return jinja.render('layout.html', request)
