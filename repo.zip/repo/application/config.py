class Config(object):
    DEVELOPMENT_MODE = True
    DEBUG = True
    STATIC_URL = '/static'
    
    
    AUTH_LOGIN_ENDPOINT = 'login'
    AUTH_PASSWORD_HASH = 'sha512_crypt'
    AUTH_PASSWORD_SALT = 'add_salt'
    SECRET_KEY = 'acndef'
    SESSION_COOKIE_SALT = 'salt_key'
#     storage img

    REDIS_URI = 'localhost'
    REDIS_DB = 0
    
    MOTOR_URI = 'mongodb://localhost:27017/do_an_tai'
    
  
    