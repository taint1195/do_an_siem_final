from gatco_sqlalchemy import SQLAlchemy
import redis
# import uvloop
# import asyncio
# import motor.motor_asyncio
# from sanic_motor import BaseModel

# from sanic_useragent import SanicUserAgent

import pymongo
from pymongo import MongoClient

db = SQLAlchemy()
redis_db = redis.StrictRedis(host="localhost", port=6379, db=1)
# client = MongoClient('localhost', 27017)
client = MongoClient('localhost', 27017, maxPoolSize=100)
dbm = client.do_an_tai
#dbm.DeviceLogAccess.create_index([("mac_ap", pymongo.ASCENDING),("device_id", pymongo.ASCENDING),("access_time", pymongo.ASCENDING)], unique=False)


#cuong add motor
from gatco_motor import Motor
motordb = Motor()

@motordb.user_open_connection
async def user_open_connection(*args, **kw):
    result = await motordb.db.DeviceLogAccess.create_index([("mac_ap", pymongo.ASCENDING),("device_id", pymongo.ASCENDING),("access_time", pymongo.ASCENDING)], unique=False)
    print("user_open_connection", result)

def init_database(app):
    db.init_app(app)
    motordb.init_app(app)
    
    
    