from sqlalchemy import (
    Column, String, Integer, DateTime, Date, Boolean, DECIMAL, Text, ForeignKey, UniqueConstraint
)
#from sqlalchemy import *
from sqlalchemy.orm import *
from sqlalchemy.dialects.postgresql import UUID

#from sqlalchemy.orm import relationship, backref

from application.database import db
from application.database.model import CommonModel
# from application.models import Tenant


roles_users = db.Table('roles_users',
                       db.Column('user_id', db.Integer(), db.ForeignKey('user.id')),
                       db.Column('role_id', db.Integer(), db.ForeignKey('role.id')))


class Role(CommonModel):
    id = db.Column(db.Integer(), primary_key=True)
    role_name = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(255))
    
class User(CommonModel):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    email = db.Column(db.String(255), unique=True)
    password = db.Column(db.String(255))
    active = db.Column(db.Boolean())
    confirmed_at = db.Column(db.DateTime())
    phone = db.Column(db.String(255), unique=True)
    roles = db.relationship('Role', secondary=roles_users,
                            backref=db.backref('users', lazy='dynamic'))
    
    tenancy_id = db.Column(db.Integer, db.ForeignKey('tenancy.id'), nullable=True)
    tenancy = db.relationship('Tenancy', backref=db.backref('users', lazy='dynamic'))
    
    last_login_at = db.Column(db.DateTime())
    current_login_at = db.Column(db.DateTime())
    last_login_ip = db.Column(db.String(255))
    current_login_ip = db.Column(db.String(255))
    login_count = db.Column(db.Integer)
    birthday = db.Column(db.DateTime())
    gender = db.Column(db.String(255))
    
    def __repr__(self):
        """ Show user object info. """
        return '<User: {}>'.format(self.id)
    
    def has_role(self, role):
        if isinstance(role, str):
            return role in (role.role_name for role in self.roles)
        else:
            return role in self.roles
    
    def add_role(self, role):
        pass
    
    def remove_role(self,role):
        pass


class Permission(CommonModel):
    __tablename__ = 'permission'
    id = db.Column(Integer(), primary_key=True)
    role_id = db.Column(Integer, ForeignKey('role.id'), nullable=False)
    subject = db.Column(String,index=True)
    permission = db.Column(String)
    value = db.Column(Boolean, default=False)
    __table_args__ = (UniqueConstraint('role_id', 'subject', 'permission', name='uq_permission_role_subject_permission'),)
    
    
    