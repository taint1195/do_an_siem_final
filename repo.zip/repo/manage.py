""" Module for managing tasks through a simple cli interface. """
# Libraries

import sys
import json

from os.path import abspath, dirname
sys.path.insert(0, dirname(abspath(__file__)))

from sqlalchemy.inspection import inspect
from sqlalchemy.engine import reflection

from manager import Manager

from application import run_app
from application.database import  dbm
from application.extensions import auth

import random
import string

from application.models.user import Role, User, Permission

# Constants.
manager = Manager()




@manager.command
def run():
    """ Starts server on port 80.. """
    run_app(host="0.0.0.0")
    


@manager.command
def create_role_mongo():
    """ Create default data. """
    dbm.role.insert_one({'role_name' :'ADMIN', 'description' :"Admin"})
    return

def generate_salt():
    code = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(32))
    return code

@manager.command
def create_admin_mongo():
    roles= []
    role = dbm.role.find_one({'role_name' :'ADMIN'})
    del role['_id']
    roles.append(role)
    data = {}
    data['salt'] = generate_salt()
    data['phone'] = '0366999497'
    data['full_name'] = 'Nguyen Tan Tai'
    data['email'] = 'admin'
    data['user_name'] = 'admin'
    data['password'] = auth.encrypt_password('123456', data['salt'])
    data['roles'] = roles
    data['active'] = True 
    dbm.user.insert_one(data)

if __name__ == '__main__':
    manager.main()
